#include <iostream>
#include "Semester.h"

int main()
{
    return 0;
}