#include <iostream>
#include "Semester.h"

Book::Book(std::string BookID, std::string BookName, std::string publisher, int quantiny, double price) 
{
    this->BookID = BookID;
    this->BookName = BookName;
    this->publisher = publisher;
    this->quantiny = quantiny;
    this->price = price;
}

Book::~Book() {}

void Book::display() 
{
    std::cout << "Ma sach: " << BookID << std::endl;
    std::cout << "Ten sach: " << BookName << std::endl;
    std::cout << "Nha xuat ban: " << publisher << std::endl;
    std::cout << "So luong: " << quantiny << std::endl;
    std::cout << "Don gia: " << price << std::endl;
}